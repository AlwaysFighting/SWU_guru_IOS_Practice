//
//  DateValue.swift
//  TravelApplication
//
//  Created by 목정아 on 2022/07/21.
//

import SwiftUI

struct DateValue: Identifiable{
    var id = UUID().uuidString
    var day: Int
    var date: Date
}
