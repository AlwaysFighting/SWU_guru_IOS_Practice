import SwiftUI

struct Seoul: View {
    var body: some View {
        Text("Hello, Seoul!")
    }
}

struct Seoul_Previews: PreviewProvider {
    static var previews: some View {
        Seoul()
    }
}
